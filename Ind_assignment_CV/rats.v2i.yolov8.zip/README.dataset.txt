# rats > 2024-06-23 5:37pm
https://universe.roboflow.com/ie-e5z7g/rats-fi9by

Provided by a Roboflow user
License: MIT

